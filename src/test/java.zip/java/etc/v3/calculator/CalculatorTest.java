package etc.v3.calculator;

import org.joda.time.LocalTime;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

public class CalculatorTest {

    public static void main(String[] args) {
        System.out.println(new LocalTime());
    }

    private void sum() {
//        BigInteger bigInteger = new BigInteger();
    }
}

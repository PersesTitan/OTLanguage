package etc.v3.list;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ReturnListTest {
    public static void main(String[] args) {

    }
}

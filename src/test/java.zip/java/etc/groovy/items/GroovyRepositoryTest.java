package etc.groovy.items;

public interface GroovyRepositoryTest {
    String JAVA = "ㅉㅂㅉ";
    String JAVA_START = "ㅅㅌㅅ";
}

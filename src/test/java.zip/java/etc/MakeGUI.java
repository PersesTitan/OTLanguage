package etc;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;

public class MakeGUI {
    JComponent component;

    JButton button;
    Canvas canvas;
    Checkbox checkbox;
    Choice choice;
    Container container;
    /////////
    JPanel panel;
    JApplet applet;
    ///////////
    JWindow window;
    JDialog dialog;
    FileDialog fileDialog;
    JFrame frame;
    JScrollPane scrollPane;

    JLabel label;
    JList list;
    Scrollbar scrollbar;
    JTextComponent textComponent;
}

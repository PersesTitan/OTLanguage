package etc.db.item.db;

public record DBItemDTO(String name, DBType type, DBOption...option) {
}

package cos.shell;

public interface JavaRepository {

}

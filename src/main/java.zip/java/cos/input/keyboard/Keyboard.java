package cos.input.keyboard;

public class Keyboard {

}

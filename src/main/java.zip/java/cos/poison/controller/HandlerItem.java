package cos.poison.controller;

public record HandlerItem(String fileName, String startFinalTotal, String[][] params,
                          String responseValue, String contentType) { }
